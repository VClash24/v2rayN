﻿using ProtosLib.Statistics;

namespace ProtosLib
{
    public class Tests
    {
        private StatsService.StatsServiceClient client_;

        public Tests()
        {
        }
    }
}